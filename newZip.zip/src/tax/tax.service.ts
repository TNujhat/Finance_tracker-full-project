// src/tax/tax.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tax } from './tax.entity';
import { CalculateTaxDto } from './dto/calculate-tax.dto';
import { Transaction } from '../transaction/transaction.entity';

@Injectable()
export class TaxService {
  constructor(
    @InjectRepository(Tax)
    private taxRepo: Repository<Tax>,
    @InjectRepository(Transaction)
    private txRepo: Repository<Transaction>,
  ) {}

  private computeTax(income: number): number {
    let tax = 0;
    const slabs = [
      { upto: 300_000, rate: 0 },
      { upto: 400_000, rate: 0.05 },
      { upto: 700_000, rate: 0.10 },
      { upto: 1_100_000, rate: 0.15 },
      { upto: 1_600_000, rate: 0.20 },
      { upto: Infinity, rate: 0.25 },
    ];
    let remaining = income;
    let prev = 0;
    for (const { upto, rate } of slabs) {
      const chunk = Math.min(remaining, upto - prev);
      tax += chunk * rate;
      remaining -= chunk;
      prev = upto;
      if (remaining <= 0) break;
    }
    return tax;
  }

  /** সব ট্রানজেকশন একসাথে যোগ করবে—কোন userId ফিল্টার নেই */
  private async fetchTotalExpense(year: number): Promise<number> {
    const { total } = await this.txRepo
      .createQueryBuilder('tx')
      .select('SUM(tx.amount)', 'total')
      .andWhere('tx.date BETWEEN :start AND :end', {
        start: `${year}-01-01`,
        end:   `${year}-12-31`,
      })
      .getRawOne();
    return parseFloat(total) || 0;
  }

  /** হিসাব + সেভ */
  async calculateAndSave(userId: number, dto: CalculateTaxDto) {
    const deductions = await this.fetchTotalExpense(dto.year);
    const taxableIncome = Math.max(0, dto.totalIncome - deductions);
    const taxAmount = this.computeTax(taxableIncome);

    const record = this.taxRepo.create({
      userId,
      year: dto.year,
      totalIncome: dto.totalIncome,
      deductions,
      taxableIncome,
      taxAmount,
    });
    return this.taxRepo.save(record);
  }

  /** হিস্ট্রি */
  async findAllForUser(userId: number) {
    return this.taxRepo.find({
      where: { userId },
      order: { calculatedAt: 'DESC' },
    });
  }
}
