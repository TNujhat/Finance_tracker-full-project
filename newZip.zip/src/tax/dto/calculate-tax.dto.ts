// src/tax/dto/calculate-tax.dto.ts
export class CalculateTaxDto {
  readonly year: number;
  readonly totalIncome: number;
}
