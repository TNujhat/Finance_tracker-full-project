// src/tax/tax.entity.ts
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity()
export class Tax {
  @PrimaryGeneratedColumn()
  id: number;

  // যদি per-user চান, এখানে userId: number; রাখতে পারেন @Column() হিসেবে
  @Column()
  userId: number;

  @Column()
  year: number;

  @Column('float')
  totalIncome: number;

  @Column('float', { default: 0 })
  deductions: number;        // আমরা নিচে auto-calc করব

  @Column('float')
  taxableIncome: number;

  @Column('float')
  taxAmount: number;

  @CreateDateColumn()
  calculatedAt: Date;
}
