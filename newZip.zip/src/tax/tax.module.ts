// src/tax/tax.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Tax } from './tax.entity';
import { TaxService } from './tax.service';
import { TaxController } from './tax.controller';
import { Transaction } from '../transaction/transaction.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Tax, Transaction]), // Transaction থাকবে, কিন্তু এটির userId না লাগবে
  ],
  providers: [TaxService],
  controllers: [TaxController],
})
export class TaxModule {}
