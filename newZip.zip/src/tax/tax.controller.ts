// src/tax/tax.controller.ts
import { Controller, Post, Body, UseGuards, Req, Get } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { TaxService } from './tax.service';
import { CalculateTaxDto } from './dto/calculate-tax.dto';

@Controller('tax')
@UseGuards(JwtAuthGuard)
export class TaxController {
  constructor(private taxService: TaxService) {}

  @Post('calculate/save')
  calculateAndSave(@Req() req, @Body() dto: CalculateTaxDto) {
    return this.taxService.calculateAndSave(req.user.userId, dto);
  }

  @Get()
  listAll(@Req() req) {
    return this.taxService.findAllForUser(req.user.userId);
  }
}
