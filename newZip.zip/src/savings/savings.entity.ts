// src/savings/savings.entity.ts
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity()
export class Savings {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  userId: number;           // JWT থেকে পাবে

  @Column()
  year: number;

  @Column('float')
  totalIncome: number;

  @Column('float', { default: 0 })
  totalExpense: number;     // Transaction থেকে auto-calc

  @Column('float')
  savings: number;          // totalIncome - totalExpense

  @CreateDateColumn()
  calculatedAt: Date;
}
