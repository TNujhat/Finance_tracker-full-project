// src/savings/savings.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Savings } from './savings.entity';
import { CalculateSavingsDto } from './dto/calculate-savings.dto';
import { Transaction } from '../transaction/transaction.entity';

@Injectable()
export class SavingsService {
  constructor(
    @InjectRepository(Savings)
    private savingsRepo: Repository<Savings>,
    @InjectRepository(Transaction)
    private txRepo: Repository<Transaction>,
  ) {}

  /** বছরভিত্তিতে সব ট্রানজেকশন যোগ করে আসবে */
  private async fetchTotalExpense(year: number): Promise<number> {
    const { total } = await this.txRepo
      .createQueryBuilder('tx')
      .select('SUM(tx.amount)', 'total')
      .andWhere('tx.date BETWEEN :start AND :end', {
        start: `${year}-01-01`,
        end:   `${year}-12-31`,
      })
      .getRawOne();
    return parseFloat(total) || 0;
  }

  /** হিসাব + DB-তে সেভ */
  async calculateAndSave(userId: number, dto: CalculateSavingsDto) {
    const totalExpense = await this.fetchTotalExpense(dto.year);
    const savings = Math.max(0, dto.totalIncome - totalExpense);

    const record = this.savingsRepo.create({
      userId,
      year: dto.year,
      totalIncome: dto.totalIncome,
      totalExpense,
      savings,
    });
    return this.savingsRepo.save(record);
  }

  /** পূর্বের সব সেভিংস হিস্ট্রি দেখাবে */
  async findAllForUser(userId: number) {
    return this.savingsRepo.find({
      where: { userId },
      order: { calculatedAt: 'DESC' },
    });
  }
}
