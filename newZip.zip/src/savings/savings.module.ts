// src/savings/savings.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Savings } from './savings.entity';
import { SavingsService } from './savings.service';
import { SavingsController } from './savings.controller';
import { Transaction } from '../transaction/transaction.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Savings, Transaction]),
  ],
  providers: [SavingsService],
  controllers: [SavingsController],
})
export class SavingsModule {}
