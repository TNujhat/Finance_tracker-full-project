// src/savings/dto/calculate-savings.dto.ts
export class CalculateSavingsDto {
  readonly year: number;        // যে বছরের সেভিংস হিসাব করবেন
  readonly totalIncome: number; // ইউজারের মোট ইনকাম (API client থেকে)
}
