// src/savings/savings.controller.ts
import { Controller, Post, Body, UseGuards, Req, Get } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { SavingsService } from './savings.service';
import { CalculateSavingsDto } from './dto/calculate-savings.dto';

@Controller('savings')
@UseGuards(JwtAuthGuard)
export class SavingsController {
  constructor(private readonly svc: SavingsService) {}

  // ১) হিসাব + সেভ
  @Post('calculate')
  calculateAndSave(@Req() req, @Body() dto: CalculateSavingsDto) {
    return this.svc.calculateAndSave(req.user.userId, dto);
  }

  // ২) পূর্বের হিস্ট্রি
  @Get()
  listAll(@Req() req) {
    return this.svc.findAllForUser(req.user.userId);
  }
}
